package androidtown.org.termproject;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import androidtown.org.termproject.HomepagePackage.HomeFragment;
import androidtown.org.termproject.HomepagePackage.ProfileFragment;
import androidtown.org.termproject.HomepagePackage.StorageFragment;

public class PagerAdapter extends FragmentStateAdapter {


    public PagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle){
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position){
       switch (position){
           case 0:
               return new HomeFragment();
           case 1:
               return new StorageFragment();
           case 2:
               return new ProfileFragment();
           default:
               return null;
       }
    }
//    public void addFragment(Fragment fragment){
//        mFragmentList.add(fragment);
//    }

    @Override
    public int getItemCount(){
//        return mFragmentList.size();
        return 3;
    }

}
