package androidtown.org.termproject.HomepagePackage;

import static android.widget.Toast.makeText;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidtown.org.termproject.HomepagePackage.Card.saved_card;
import androidtown.org.termproject.InitPopUpActivity;
//import androidtown.org.termproject.HomepagePackage.Card.custom_card_register;

import androidtown.org.termproject.R;

public class HomeFragment extends Fragment {
    private Animation rotateOpen;
    private Animation rotateClose;
    private Animation fromBottom;
    private Animation toBottom;
    FloatingActionButton floatMenu;
    FloatingActionButton add;
    FloatingActionButton edit;
    private boolean clicked = false;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        ImageView my_namecard = getActivity().findViewById(R.id.current_namecard_image);
        DocumentReference docRef = db.collection("sampleCollection").document(Uid);

        // Firestore에서 문서 가져오기
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // 문서가 존재하면 배열을 가져옵니다.
                        List<String> imageUrlList = (List<String>) document.get("mynamecards");

                        if (imageUrlList != null && imageUrlList.size() > 0) {
                            String element_url = imageUrlList.get(0); // Get most recent namecard image url
                            if (element_url.startsWith("gs://")) {
                                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                                StorageReference imgRef = firebaseStorage.getReferenceFromUrl(element_url);
                                if (imgRef != null) {
                                    imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            Glide.with(getActivity())
                                                    .load(uri)
                                                    .centerCrop()
                                                    .into(my_namecard);
                                        }
                                    });
                                }
                            } else {
                                Glide.with(getActivity())
                                        .load(element_url)
                                        .centerCrop()
                                        .into(my_namecard);
                            }
                        }
                    }

                } else {
                    Log.d("Firestore", "No such document");
//                    Toast.makeText(getActivity().getApplicationContext(), "No such document", Toast.LENGTH_SHORT).show();
                }
            }
        });



        rotateOpen = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_open);
        rotateClose = AnimationUtils.loadAnimation(getContext(),R.anim.rotate_close);
        fromBottom = AnimationUtils.loadAnimation(getContext(),R.anim.from_bottom);
        toBottom = AnimationUtils.loadAnimation(getContext(),R.anim.to_bottom);

        floatMenu = getActivity().findViewById(R.id.floatMenu);
        floatMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddButtonClicked();
            }
        });
        edit = getActivity().findViewById(R.id.edit_btn);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddButtonClicked();
            }
        });
        add = getActivity().findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), saved_card.class);
                startActivity(intent);

            }
        });
    }
    private void onAddButtonClicked(){
        setVisibility(clicked);
        setAnimation(clicked);
        clicked = !clicked;


    }
    private void setVisibility(boolean clicked){
        if(!clicked){
//            edit.setVisibility(floatMenu.VISIBLE);
            add.setVisibility(add.VISIBLE);
        }else{
//            edit.setVisibility(floatMenu.INVISIBLE);
            add.setVisibility(add.INVISIBLE);
        }
    }
    private void setAnimation(boolean clicked){
        if(!clicked){
//            edit.startAnimation(fromBottom);
            add.startAnimation(fromBottom);
            floatMenu.startAnimation(rotateOpen);
        }else{
//            edit.startAnimation(toBottom);
            add.startAnimation(toBottom);
            floatMenu.startAnimation(rotateClose);
        }
    }
}
