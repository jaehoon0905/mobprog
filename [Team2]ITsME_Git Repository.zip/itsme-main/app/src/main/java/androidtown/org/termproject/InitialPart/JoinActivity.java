package androidtown.org.termproject.InitialPart;
import static android.content.ContentValues.TAG;

import androidtown.org.termproject.DataPage;
import androidtown.org.termproject.HomepagePackage.*;
import androidtown.org.termproject.R;
import androidtown.org.termproject.ViewPager2Adapter;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import javax.annotation.Nullable;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.app.Activity;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.tbuonomo.viewpagerdotsindicator.SpringDotsIndicator;

import java.util.ArrayList;


public class JoinActivity extends Activity implements GoogleApiClient.OnConnectionFailedListener{
    // 구글 로그인 part
    private static final int RC_SIGN_IN = 10;
    private SignInButton google_lgbtn; //구글 로그인 버튼 선언
    private Button logout_btn;
    public Button button_login; //로그인 버튼 선언
    public Button button_signup; //가입 버튼 선언
    private TextView textView;
    private GoogleSignInClient mGoogleSignInClient;
    public FirebaseAuth mAuth;
    // 구글 로그인 part



    private ViewPager2 viewPager2;
    private ViewPager2Adapter viewPager2Adapter;
    private ArrayList<DataPage> list;
    private Button login_button;
    private Button signup_button;
    private SpringDotsIndicator springDotsIndicator;
    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.join_page);


        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);



        viewPager2 = findViewById(R.id.sliderViewPager);
        springDotsIndicator =(SpringDotsIndicator) findViewById(R.id.spring_dots_indicator);

        list = new ArrayList<>();
        list.add(new DataPage(android.R.color.white,"명함을 꾸미기", R.drawable.design));
        list.add(new DataPage(android.R.color.white,"손쉽게 명함을 교환하기", R.drawable.exchange_image));
        list.add(new DataPage(android.R.color.white,"카메라로 명함 등록하기", R.drawable.register));


        viewPager2Adapter = new ViewPager2Adapter(list);
        viewPager2.setAdapter(viewPager2Adapter);
        viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        springDotsIndicator.setViewPager2(viewPager2);


//        login_button = findViewById(R.id.loginBtn);
//        login_button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                bottomSheetDialog.show();
//            }
//        });

        // 여기서 부터 구글 로그인

        mAuth = FirebaseAuth.getInstance();



        /*구글 로그인 앱에 통합*/
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        /*구글 로그인 버튼*/
        google_lgbtn = findViewById(R.id.signin_btn);
        google_lgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);

            }
        });

    }
    @Override
    public void onBackPressed(){
        //super.onBackPressed();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
//                Toast.makeText(getApplicationContext(), "onActivityResult",
//                        Toast.LENGTH_SHORT).show();
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e);
                // Handle failure here
//                Toast.makeText(this, "Google sign in failed", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void firebaseAuthWithGoogle(@Nullable GoogleSignInAccount acct) {
        if (acct != null) {
            AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
            mAuth.signInWithCredential(credential)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                FirebaseUser user = mAuth.getCurrentUser();
                                toHomepageActivity(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "signInWithCredential:failure", task.getException());
//                                Toast.makeText(JoinActivity.this, "Authentication failed.",
//                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        } else {
            Log.w(TAG, "Google sign in account is null");
            // Handle null account
        }
    }


    private void toHomepageActivity(FirebaseUser user){
//        Toast.makeText(getApplicationContext(),"성공 @ join",Toast.LENGTH_SHORT).show();
        if(user != null){
            startActivity(new Intent(this, HomePage.class));
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

}