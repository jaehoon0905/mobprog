package androidtown.org.termproject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class PopUpActivity extends Activity {
    String imageUrl = "https://cdn.news.unn.net/news/photo/202303/543364_349981_4153.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup_activity);
        // 보낸 액티비티에서 전달한 Intent 가져오기
        Intent intent = getIntent();
        // Intent로부터 Extra 추출
        if (intent != null) {
            imageUrl = intent.getStringExtra("imageUrl");
        }
        Load();
    }

    private void openViewer(String uri, ProgressBar progressBar, ImageView imageView) {
        Glide.with(getApplicationContext())
                .load(uri)
//                            .placeholder(R.drawable.ic_launcher_foreground) // 이미지 로딩 중에 보여줄 이미지
                .error(R.drawable.ic_launcher_foreground) // 이미지 로딩 실패 시 보여줄 이미지
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
//                                    imageView.setVisibility(View.GONE);  // Optional: Hide ImageView if loading failed
                        imageView.setVisibility(View.INVISIBLE);  // Hide ImageView if loading failed

                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
//                                    imageView.setVisibility(View.VISIBLE);
                        imageView.setVisibility(View.VISIBLE);  // Show ImageView when image is ready

                        return false;
                    }
                })
                .override(Target.SIZE_ORIGINAL) // 원본 크기로 이미지 로드
                .into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        // 이미지가 로드되면 이미지의 너비와 높이를 가져옴
                        int imageWidth = resource.getIntrinsicWidth();
                        int imageHeight = resource.getIntrinsicHeight();

                        // 이미지뷰의 너비 가져오기
                        int targetWidth = imageView.getWidth();

                        // 이미지의 비율 계산
                        float aspectRatio = (float) imageHeight / (float) imageWidth;

                        // 이미지뷰의 높이를 이미지의 비율에 맞게 계산
                        int targetHeight = Math.round(targetWidth * aspectRatio);

                        // 이미지뷰의 크기 변경
                        imageView.getLayoutParams().width = targetWidth;
                        imageView.getLayoutParams().height = targetHeight;
                        imageView.requestLayout(); // 레이아웃 갱신

                        // 이미지 표시
                        imageView.setImageDrawable(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        // 이미지 로드가 취소되거나 클리어될 때 호출되는 부분
                    }
                });
//                    imageView.getLayoutParams().height = "300px";
    }

    private void Load() {
        ImageView imageView = findViewById(R.id.namecardImage);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        if (imageUrl.startsWith("gs://")) {
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference imgRef = firebaseStorage.getReferenceFromUrl(imageUrl);
            if (imgRef != null) {
//                Toast.makeText(getApplicationContext(), imgRef.toString(), Toast.LENGTH_SHORT).show();
                imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {

                    @Override
                    public void onSuccess(Uri uri) {
//                        Toast.makeText(getApplicationContext(), uri.toString(), Toast.LENGTH_SHORT).show();
                        openViewer(uri.toString(), progressBar, imageView);
                    }

                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
//                        Toast.makeText(getApplicationContext(), "실패" + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            openViewer(imageUrl, progressBar, imageView);
        }
    }
}