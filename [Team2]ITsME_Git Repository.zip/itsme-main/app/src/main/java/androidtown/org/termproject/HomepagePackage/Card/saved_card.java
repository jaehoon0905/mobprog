package androidtown.org.termproject.HomepagePackage.Card;

import static android.content.ContentValues.TAG;

import androidtown.org.termproject.HomepagePackage.HomePage;
import androidtown.org.termproject.HomepagePackage.ProfileFragment;
import androidtown.org.termproject.R;
import ja.burhanrashid52.photoeditor.CustomEffect;
import ja.burhanrashid52.photoeditor.DrawingView;

import ja.burhanrashid52.photoeditor.OnPhotoEditorListener;
import ja.burhanrashid52.photoeditor.OnSaveBitmap;
import ja.burhanrashid52.photoeditor.PhotoEditor;
import ja.burhanrashid52.photoeditor.PhotoEditorView;
import ja.burhanrashid52.photoeditor.PhotoFilter;
import ja.burhanrashid52.photoeditor.SaveFileResult;
import ja.burhanrashid52.photoeditor.SaveSettings;
import ja.burhanrashid52.photoeditor.TextStyleBuilder;
import ja.burhanrashid52.photoeditor.ViewType;
import ja.burhanrashid52.photoeditor.shape.ShapeBuilder;
import ja.burhanrashid52.photoeditor.shape.ShapeType;
import kotlin.coroutines.Continuation;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.effect.EffectFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.method.MovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class saved_card extends AppCompatActivity {

    private DrawingView mDrawingView;

    private static final int REQUEST_CODE_COLOR_PICKER = 1;
    private static final int REQUEST_EDIT_TEXT = 3;

    private static final int REQUEST_SAVE = 5;

    private SeekBar eraseBar;
    private float eraseSize;

    private SeekBar brushBar;
    private float brushSize;

    private Integer colorCode;
    private Integer textColor;

    private ShapeBuilder shapeBuilder;

    private PhotoEditor mPhotoEditor;

    private PhotoEditorView mPhotoEditorView;

    String Uid;

    private FirebaseStorage storage;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.saved_card);

        storage = FirebaseStorage.getInstance();
        firestore = FirebaseFirestore.getInstance();

        shapeBuilder = new ShapeBuilder();

        // 지우개 사이즈
        eraseBar = findViewById(R.id.erase_bar);
        eraseSize = eraseBar.getProgress();

        // 페인트 사이즈
        brushBar = findViewById(R.id.brush_bar);
        brushSize = brushBar.getProgress();

        mDrawingView = findViewById(R.id.DrawingView);

        mPhotoEditorView =findViewById(R.id.photoEditorView);

        mPhotoEditor = new PhotoEditor.Builder(getApplicationContext(), mPhotoEditorView)
                .setPinchTextScalable(true)
                .build();


        BottomNavigationView navigation = findViewById(R.id.navigation);

        // 선택 했을 때 ---------------------------------
        navigation.setOnNavigationItemSelectedListener(item -> {
            if(item.getItemId() == R.id.action_text) {

                eraseBar.setVisibility(View.GONE);
                brushBar.setVisibility(View.GONE);
                item.setChecked(true);
                Intent in = new Intent(saved_card.this, popup_edittext.class);
                startActivityForResult(in, REQUEST_EDIT_TEXT);
                mDrawingView.enableDrawing(false);

            }else if(item.getItemId() == R.id.action_paint) {
                shapeBuilder.withShapeSize(brushSize);
                brushBar.setVisibility(View.VISIBLE);
                eraseBar.setVisibility(View.GONE);
                item.setChecked(true);
                Intent intent = new Intent(saved_card.this, Popup_background.class);
                startActivityForResult(intent, REQUEST_CODE_COLOR_PICKER);

            }else if(item.getItemId() == R.id.erase) {

                shapeBuilder.withShapeSize(eraseSize);
                eraseBar.setVisibility(View.VISIBLE);
                brushBar.setVisibility(View.GONE);
                item.setChecked(true);

                // 지우개 색 화이트로 지정
                shapeBuilder.withShapeColor(-1);
                mDrawingView.enableDrawing(true);
                mDrawingView.setCurrentShapeBuilder(shapeBuilder);
                //mDrawingView.brushEraser();

            } else if (item.getItemId() == R.id.save_nav){
                mDrawingView.enableDrawing(false);
                eraseBar.setVisibility(View.GONE);
                brushBar.setVisibility(View.GONE);
                item.setChecked(true);
                Intent intent = new Intent(saved_card.this, popup_save.class);
                startActivityForResult(intent, REQUEST_SAVE);

            }

            return false;
        });

        eraseBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                eraseSize = seekBar.getProgress();
                //mDrawingView.setEraserSize(eraseSize);
                shapeBuilder.withShapeSize(eraseSize);
            }
        });

        brushBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }


            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(saved_card.this, " " + brushSize, Toast.LENGTH_SHORT).show();
                brushSize = seekBar.getProgress();
                //mDrawingView.setEraserSize(brushSize);
                shapeBuilder.withShapeSize(brushSize);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_COLOR_PICKER && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("color_code")) {
                int colorCode = data.getIntExtra("color_code", -1);
                if (colorCode != -1) {
                    this.colorCode = colorCode;
                    enablePaintMode();
                }
            }
        } else if (requestCode == REQUEST_EDIT_TEXT && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("set_text")) {
                ArrayList<String> as = (ArrayList<String>) data.getSerializableExtra("set_text");
                String editText = as.get(0);
                textColor = Integer.parseInt(as.get(1));
                addText(editText,textColor);
            }
        } else if(requestCode == REQUEST_SAVE && resultCode == RESULT_OK){
            if (data != null && data.hasExtra("CONFIRM")) {
               String text = data.getStringExtra("CONFIRM");

               if(text.equals("OK")){
                   saveAndUploadImage();

                   new Handler().postDelayed(new Runnable()
                   {
                       @Override
                       public void run()
                       {
                           //딜레이 후 시작할 코드 작성
                           startActivity(new Intent(getApplicationContext() , HomePage.class));
                       }
                   }, 1300);// 1초 정도 딜레이를 준 후 시작


               }
            }
        }

    }

    private void addText(String text, Integer textColor) {
        TextStyleBuilder textStyleBuilder = new TextStyleBuilder();

        textStyleBuilder.withTextColor(textColor);
        textStyleBuilder.withTextSize(20);
        mPhotoEditor.addText(text,textStyleBuilder);
    }


    private void enablePaintMode() {
        shapeBuilder.withShapeColor(colorCode);
        mDrawingView.enableDrawing(true);
        mDrawingView.setCurrentShapeBuilder(shapeBuilder);
    }

    // 사진을 파이어 스토리지에 저장
    private void saveAndUploadImage() {
        Toast.makeText(saved_card.this, "Image upload called!", Toast.LENGTH_SHORT).show();
        try {
            SaveSettings saveSettings = new SaveSettings.Builder()
                    .setClearViewsEnabled(false)
                    .setTransparencyEnabled(false)
                    .build();

            Toast.makeText(saved_card.this, "in try block!", Toast.LENGTH_SHORT).show();
            mPhotoEditor.setFilterEffect(PhotoFilter.BRIGHTNESS);
            mPhotoEditor.saveAsBitmap(saveSettings, new OnSaveBitmap() {
                @Override
                public void onBitmapReady(@NonNull Bitmap bitmap) {
                    Toast.makeText(saved_card.this, "saveBitmap=" + bitmap.toString(), Toast.LENGTH_SHORT).show();
                    // Bitmap to byte array
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                    byte[] data = baos.toByteArray();
                    Toast.makeText(saved_card.this, "onBitmapReady called. byte size=" + Integer.toString(data.length), Toast.LENGTH_SHORT).show();

                    // byte array to firebase storage
                    StorageReference storageRef = storage.getReference();
                    StorageReference imagesRef = storageRef.child("images/" + System.currentTimeMillis() + ".png");
                    UploadTask uploadTask = imagesRef.putBytes(data);
                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // 업로드 성공 시 다운로드 URL 가져오기
                            imagesRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String downloadUrl = uri.toString();
                                    saveImageUrlToFirestore(downloadUrl);
                                    Toast.makeText(saved_card.this, "Image upload OK: " + downloadUrl, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // 업로드 실패 처리
                            Toast.makeText(saved_card.this, "Image upload failed: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error initializing save operation", e);
            Toast.makeText(saved_card.this, "Error initializing save operation", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveImageUrlToFirestore(String url) {
        // Firestore와 Firebase를 사용할 수 있도록 설정
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // 사용자 UID
        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // 컬렉션과 문서 참조
        DocumentReference docRef = db.collection("sampleCollection").document(Uid);

        // Firestore에서 문서 가져오기
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // 문서가 존재하면 배열을 가져옵니다.
                        List<String> array = (List<String>) document.get("mynamecards");

                        // 배열이 null이 아닌지 확인합니다.
                        if (array == null) {
                            array = new ArrayList<>();
                        }

                        // 새 문자열을 배열의 맨 앞에 추가합니다.
                        array.add(0, url);

                        // Firestore에 업데이트된 배열을 저장합니다.
                        docRef.update("mynamecards", array)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d("Firestore", "DocumentSnapshot successfully updated!");
                                        Toast.makeText(getApplicationContext(), "DocumentSnapshot successfully updated", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("Firestore", "Error updating document", e);
                                        Toast.makeText(getApplicationContext(), "Error updating document : " + e.toString(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Log.d("Firestore", "No such document");
                        Toast.makeText(getApplicationContext(), "No such document", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.d("Firestore", "get failed with ", task.getException());
                    Toast.makeText(getApplicationContext(), "get failed with : " + task.getException().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private File saveBitmapToFile(Bitmap bitmap) {
        try {
            File file = new File(getCacheDir(), "saved_image.png");
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            return file;
        } catch (Exception e) {
            Log.e(TAG, "Error saving bitmap to file", e);
            return null;
        }
    }

    private void uploadImageToFirebase(File file) {
        Uri fileUri = Uri.fromFile(file);
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

        Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String fileName = "IMG_" + sdf.format(new Date()) + ".png";

        StorageReference imgRef = firebaseStorage.getReference("photo/" + Uid + "/" + fileName);

        imgRef.putFile(fileUri)
                .addOnSuccessListener(taskSnapshot -> {
                    Toast.makeText(saved_card.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error uploading image", e);
                    Toast.makeText(saved_card.this, "Image upload failed", Toast.LENGTH_SHORT).show();
                });
    }


}
