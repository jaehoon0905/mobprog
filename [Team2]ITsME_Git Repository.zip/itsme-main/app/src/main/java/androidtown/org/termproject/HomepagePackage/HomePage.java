package androidtown.org.termproject.HomepagePackage;


import static android.app.PendingIntent.getActivity;

import static java.security.AccessController.getContext;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import androidtown.org.termproject.InitPopUpActivity;
import androidtown.org.termproject.PopUpActivity;
import androidtown.org.termproject.R;
import androidtown.org.termproject.databinding.HomePageBinding;


public class HomePage extends AppCompatActivity {
    int i =0;
    BottomNavigationView bottomNavigationView;
    BottomSheet bottomSheet;
    private HomePageBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = HomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bottomNavigationView = findViewById(R.id.bottomNavi);
        getSupportFragmentManager().beginTransaction().replace(R.id.main_content, new HomeFragment()).commit();

        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("sampleCollection").document(Uid)
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (!document.exists()) {
//                                Toast.makeText(getApplicationContext(), document.toString(), Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), InitPopUpActivity.class);
                                startActivity(intent);
                            }

                        } else {
//                            Toast.makeText(getApplicationContext(), "실패애앵ㄹ", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.home){
                    transferTo(new HomeFragment());
                    return true;
                }
                else if(item.getItemId() == R.id.exchange){
                    transferTo(new ExchangeFragment());
                    return true;
                }
                else if(item.getItemId() == R.id.camera){
                    transferTo(new CameraFragment());
                    return true;
                }
                else if(item.getItemId() == R.id.storage){
                    transferTo(new StorageFragment());
                    return true;
                }
                else if(item.getItemId() == R.id.profile){
                    transferTo(new ProfileFragment());
                    return true;
                }
                return false;
            }
        });
    }
    void transferTo(Fragment fragment){
        getSupportFragmentManager().beginTransaction().replace(R.id.main_content, fragment).commit();
    }
}
