package androidtown.org.termproject;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.vision.L;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class PopUpActivity_profileMenu extends Activity {


    Button delete, setcurrent;
    String targetDocId = null;
    int imageArrayIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup_activity_profilemenu);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        if (intent != null) {
            imageArrayIndex = intent.getIntExtra("imageArrayIndex", -1);
        }

        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        delete = findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseFirestore db = FirebaseFirestore.getInstance();
                String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DocumentReference docRef = db.collection("sampleCollection").document(Uid);

                // Firestore에서 문서 가져오기
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // 문서가 존재하면 배열을 가져옵니다.
                                List<String> imageUrlList = (List<String>) document.get("mynamecards");

                                // 배열이 null이 아닌지 확인합니다.
                                if (imageUrlList == null) {
                                    imageUrlList = new ArrayList<>();
                                }

                                // 요소를 제거하고 저장
                                String element_url = imageUrlList.remove(imageArrayIndex); // Get most recent namecard image url

                                // 요소를 맨 앞에 추가
                                docRef.update("mynamecards", imageUrlList)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    // Element successfully removed
                                                    System.out.println("Current namecard update successfully");
                                                } else {
                                                    // Handle the error
                                                    System.err.println("Error update : " + task.getException());
                                                }
                                            }
                                        });

                            }
                        }
                    }
                });
                Intent intent = new Intent();
                intent.putExtra("delete", true);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
        setcurrent = findViewById(R.id.btnsetcurrent);
        setcurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseFirestore db = FirebaseFirestore.getInstance();
                String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DocumentReference docRef = db.collection("sampleCollection").document(Uid);

                // Firestore에서 문서 가져오기
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // 문서가 존재하면 배열을 가져옵니다.
                                List<String> imageUrlList = (List<String>) document.get("mynamecards");

                                // 배열이 null이 아닌지 확인합니다.
                                if (imageUrlList == null) {
                                    imageUrlList = new ArrayList<>();
                                }

                                // 요소를 제거하고 저장
                                String element_url = imageUrlList.remove(imageArrayIndex); // Get most recent namecard image url

                                // 요소를 맨 앞에 추가
                                imageUrlList.add(0, element_url);
                                docRef.update("mynamecards", imageUrlList)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    // Element successfully removed
                                                    System.out.println("Current namecard update successfully");
                                                } else {
                                                    // Handle the error
                                                    System.err.println("Error update : " + task.getException());
                                                }
                                            }
                                        });

                            }
                        }
                    }
                });
                Intent intent = new Intent();
                intent.putExtra("delete", true);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    public void mOnClose(View v) {
        finish();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 바깥 레이어 클릭시 안닫히게
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        //안드로이드 백버튼 막기
        return;
    }
}