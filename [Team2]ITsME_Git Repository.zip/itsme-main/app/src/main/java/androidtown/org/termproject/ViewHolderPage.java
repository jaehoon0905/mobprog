package androidtown.org.termproject;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import androidtown.org.termproject.DataPage;
import androidtown.org.termproject.R;

public class ViewHolderPage extends RecyclerView.ViewHolder {
    private TextView tv_title;
    private RelativeLayout rl_layout;
    private ImageView iv_image;
    DataPage data;

    ViewHolderPage(View itemView){
        super(itemView);
        tv_title = itemView.findViewById(R.id.pager_item_text);
        rl_layout = itemView.findViewById(R.id.pager_item_bg);
        iv_image = itemView.findViewById(R.id.pager_item_image);
    }

    public void onBind(DataPage data){
        this.data = data;

        tv_title.setText(data.getTitle());
        rl_layout.setBackgroundResource(data.getColor());
        iv_image.setImageResource(data.getImage());
    }

}