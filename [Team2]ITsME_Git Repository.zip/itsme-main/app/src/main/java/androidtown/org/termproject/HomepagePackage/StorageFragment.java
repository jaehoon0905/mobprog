package androidtown.org.termproject.HomepagePackage;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.TELECOM_SERVICE;
import static android.content.Intent.getIntent;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

import static com.google.zxing.integration.android.IntentIntegrator.REQUEST_CODE;

import androidtown.org.termproject.PopUpActivity;
import androidtown.org.termproject.PopUpActivity_menu;
import androidtown.org.termproject.R;
import androidtown.org.termproject.data.*;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

// Import DB (Firebase Firestore) related Modules - 파이어베이스 관련 모듈들
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StorageFragment extends Fragment {
    private static final int REQUEST_CODE = 1;
    private static final int POPUP_REQUEST_CODE = 1;
    private LinearLayout parentLayout;
    private List<Integer> LayoutIds = new ArrayList<>();
//    private LinearLayout layout;
    private Map<Integer, LinearLayout> layouts =new HashMap<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.storage_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        parentLayout = getActivity().findViewById(R.id.linear);
        FrameLayout stroageFragmentFrameLayout = (FrameLayout) view.findViewById(R.id.stroageFragmentFrameLayout);
        List<TextView> tv = new ArrayList<TextView>(10);


//        List<DocumentReference> namecards = new ArrayList<DocumentReference>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // collection parameter -> user, .. / document parameter -> user id
        db.collection("sampleCollection").document(Uid)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();

                            // 나(사용자) 자료 구하기
                            if (document.exists()) {
//                                String toastMsg = "FireStore: " + document.getId() + " => " + document.getData();
//                                Toast.makeText(getActivity().getApplicationContext(),toastMsg, Toast.LENGTH_SHORT).show();

                                // 명함들을 그리기 위한 레이아웃 준비
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                        ((int) WRAP_CONTENT,
                                                (int) WRAP_CONTENT);
                                params.leftMargin=18;

                                LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(
                                        (int) WRAP_CONTENT,
                                        (int) WRAP_CONTENT
                                );
                                LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(
                                        (int) WRAP_CONTENT,
                                        (int) WRAP_CONTENT
                                );
                                params2.topMargin=90;
                                // 나(사용자)가 가지고 있는 명함들을 기준으로 그 사람들 자료 구하기
                                User user = document.toObject(User.class);

                                int namecard_i = 0;
                                if (user.getNamecards() != null) {
                                    for (DocumentReference obj : user.getNamecards()) {
                                        // Firebase에서 명함 자료 받아오기
                                        //                                    int finalI = namecard_i;
                                        obj.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot document = task.getResult();
                                                    if (document.exists()) {
                                                        // 명함을 통해 이름 받아옴

                                                        String mm = String.valueOf(document.getData().get("name"));
                                                        String phone = String.valueOf(document.getData().get("phoneNum"));


                                                        String namecardImgUrl = "https://cdn.news.unn.net/news/photo/202303/543364_349981_4153.jpg";
                                                        List<String> namecardImgUrls = (List<String>) document.getData().get("mynamecards");
                                                        if (namecardImgUrls != null && namecardImgUrls.size() > 0) {
                                                            //                                                        Toast.makeText(getActivity().getApplicationContext(), "aa", Toast.LENGTH_SHORT).show();
                                                            namecardImgUrl = namecardImgUrls.get(0); // 가장 최근 명함 - 맨 앞
                                                            for (int i = 0; i < namecardImgUrls.size(); i++) {
                                                                //                                                            Toast.makeText(getActivity().getApplicationContext(), namecardImgUrls.get(i), Toast.LENGTH_SHORT).show();
                                                            }
                                                        }

                                                        params.topMargin = 10;
                                                        // 받아온 이름을 display
                                                        //storage layout
                                                        LinearLayout layout = new LinearLayout(getContext());
                                                        int dynamicId = View.generateViewId();
                                                        layout.setId(dynamicId);
                                                        layout.setOrientation(LinearLayout.HORIZONTAL);
                                                        layout.setBackground(getResources().getDrawable(R.drawable.dropshadow));
                                                        layout.setLayoutParams(params);
                                                        layout.setGravity(Gravity.CENTER_HORIZONTAL);
                                                        Button b = new Button(getContext());
                                                        ImageButton b1 = new ImageButton(getContext());
                                                        b.setBackground(getResources().getDrawable(R.drawable.storage_rectangle));
                                                        b.setStateListAnimator(null);
                                                        b.setAutoLinkMask(4);
                                                        b.setText(mm + "\n" + phone);
                                                        b.setTextSize((float) 20);
                                                        b.setGravity(Gravity.LEFT);
                                                        b.setPadding(60, 50, 470, 50);
                                                        b.setLayoutParams(params1);
                                                        b1.setBackground(getResources().getDrawable(R.drawable.actionbuttonicon));
                                                        b1.setPadding(30, 30, 60, 30);
                                                        b1.setLayoutParams(params2);
                                                        layout.addView(b);
                                                        layout.addView(b1);
                                                        parentLayout.addView(layout);
                                                        String finalNamecardImgUrl = namecardImgUrl;
                                                        LayoutIds.add(dynamicId);
                                                        b.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                Intent intent = new Intent(getActivity(), PopUpActivity.class);
                                                                intent.putExtra("imageUrl", finalNamecardImgUrl);
                                                                startActivity(intent);
                                                            }
                                                        });
                                                        b1.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                Intent intent = new Intent(getActivity(), PopUpActivity_menu.class);
                                                                intent.putExtra("elemDocRef", document.getReference().getId());
                                                                //                                                            Toast.makeText(getContext(),"Layout ID:"+layout.getId(), Toast.LENGTH_SHORT).show();
                                                                startActivityForResult(intent, REQUEST_CODE);
                                                            }
                                                        });


                                                    }

                                                }
                                            }
                                        });
                                        namecard_i++;
                                    }
                                }


                                } else {
                                    String toastMsg = "자료가 없습니다!";
    //                                Toast.makeText(getActivity().getApplicationContext(), toastMsg, Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                String toastMsg = "Database에서 자료를 가져오는 데 실패했습니다 : " + task.getException();
    //                            Toast.makeText(getActivity().getApplicationContext(), toastMsg, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().detach(this).commit();

            ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().attach(this).commit();
        }
    }


}