package androidtown.org.termproject.data;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.PropertyName;

import java.util.ArrayList;
import java.util.List;

public class User {

    @PropertyName("namecards")
    private List<DocumentReference> namecards;

    public User() {
        // Must have a public no-argument constructor
    }

    // Initialize all fields of a dungeon
    public User(List<DocumentReference> namecards) {
        this.namecards = namecards;
    }

    @PropertyName("namecards")
    public List<DocumentReference> getNamecards() {
        return namecards;
    }

//    @PropertyName("namecards")
//    public void setDungeonGroup(List<String> dungeonGroup) {
//        this.namecards = namecards;
//    }

}
