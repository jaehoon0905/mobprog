package androidtown.org.termproject.HomepagePackage.Card;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;
import com.skydoves.colorpickerview.sliders.AlphaSlideBar;
import com.skydoves.colorpickerview.sliders.BrightnessSlideBar;

import androidtown.org.termproject.R;

public class Popup_background extends Activity {

    private TextView colorTextView;
    private View colorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup_background);

        colorView = findViewById(R.id.color_view);
        colorTextView = findViewById(R.id.color_text_view);
        Button btn = findViewById(R.id.btn2);
        ColorPickerView colorPickerView = findViewById(R.id.colorPickerView);
        BrightnessSlideBar brigSliderBar = findViewById(R.id.bring_slider);
        colorPickerView.attachBrightnessSlider(brigSliderBar);

        AlphaSlideBar alphaSlideBar = findViewById(R.id.alph_sliderBar);
        colorPickerView.attachAlphaSlider(alphaSlideBar);

        colorPickerView.setColorListener(new ColorEnvelopeListener() {
            @Override
            public void onColorSelected(ColorEnvelope envelope, boolean fromUser) {
                colorTextView.setText(envelope.getHexCode());
                colorView.setBackgroundColor(envelope.getColor());
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int colorCode = envelope.getColor();
                        Intent intent = new Intent();
                        intent.putExtra("color_code", colorCode);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                });
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 바깥 레이어 클릭 시 안 닫히게
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        // 안드로이드 백버튼 막기
    }
}
