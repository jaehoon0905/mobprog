package androidtown.org.termproject;

public class DataPage {
    int color;
    int image;
    String title;
    public DataPage(int color, String title, int image){
        this.color = color;
        this.title = title;
        this.image = image;
    }
//    @Override
//    public String toString() {
//        return "DataPage{" +
//                "color=" + color +
//                ", title=" + title +
//                ", image=" + image +
//                '}';
//    }
    public int getColor(){
        return color;
    }
    public void setColor(int color){
        this.color = color;
    }
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public int getImage(){
        return image;
    }
    public void setImage(int image){
        this.image = image;
    }
}
