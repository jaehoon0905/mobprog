package androidtown.org.termproject.HomepagePackage;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.BlockThreshold;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.ai.client.generativeai.type.HarmCategory;
import com.google.ai.client.generativeai.type.SafetySetting;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.graphics.Matrix;
import android.media.ExifInterface;

import android.widget.TextView;

//import com.googlecode.tesseract.android.TessBaseAPI;

//import com.googlecode.tesseract.android.TessBaseAPI;

import androidtown.org.termproject.HomepagePackage.Card.saved_card;
import androidtown.org.termproject.R;
import androidtown.org.termproject.ScanQR;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

// Import DB (Firebase Firestore) related Modules - 파이어베이스 관련 모듈들
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


public class CameraFragment extends Fragment {
    public static final int REQUEST_CODE_PHOTO = 2000;
    public static final int REQUEST_CODE_CAMERA = 2006;

    Bitmap image; //사용되는 이미지
    private String imageFilePath; //이미지 파일 경로
    private Uri p_Uri;
    BottomSheet bottomSheet;
    static final int REQUEST_IMAGE_CAPTURE = 672;
    View v;

    String Uid;

    FirebaseFirestore db;
    private FirebaseStorage storage;

//    ArrayList<EditText> editTextList = new ArrayList<>();

    ArrayList<EditText> keyEditText = new ArrayList<>();
    ArrayList<EditText> valEditText = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.camera_fragment, container, false);
        bottomSheet = new BottomSheet();
        bottomSheet.parent = this;
        bottomSheet.show(getFragmentManager(), bottomSheet.getTag());
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = FirebaseFirestore.getInstance();
        Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
// 권한ID를 가져옵니다
        int permission = ContextCompat.checkSelfPermission(getContext(),
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE);

        int permission2 = ContextCompat.checkSelfPermission(getContext(),
                android.Manifest.permission.READ_EXTERNAL_STORAGE);

//        Toast.makeText(getActivity().getApplicationContext(), "permission1" + permission, Toast.LENGTH_SHORT).show();
//        Toast.makeText(getActivity().getApplicationContext(), "permission2" + permission2, Toast.LENGTH_SHORT).show();
        // 권한이 열려있는지 확인
        if (permission == PackageManager.PERMISSION_DENIED ||
                permission2 == PackageManager.PERMISSION_DENIED) {
//            Toast.makeText(getActivity().getApplicationContext(), "PackageManager.PERMISSION_DENIED" + PackageManager.PERMISSION_DENIED, Toast.LENGTH_SHORT).show();
            // 마쉬멜로우 이상버전부터 권한을 물어본다
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // 권한 체크(READ_PHONE_STATE의 requestCode를 1000으로 세팅
                requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
//                Toast.makeText(getActivity().getApplicationContext(), "NewPictureStart", Toast.LENGTH_SHORT).show();
            }
        }

//        if (ContextCompat.checkSelfPermission(getContext(),
//                android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                == PackageManager.PERMISSION_GRANTED) {
//
//            filePath = openCamera();
//        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1000:
                if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
//                        Toast.makeText(getActivity().getApplicationContext(),"위치 권한 성공",Toast.LENGTH_LONG).show();

//                        Toast.makeText(getActivity().getApplicationContext(),"오픈카메라콜공",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity().getApplicationContext(), "위치 권한 성공", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }


    private int exifOrientationToDegrees(int exifOrientation) {
        if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
            return 90;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 180;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
            return 270;
        }
        return 0;
    }

    private Bitmap rotate(Bitmap bitmap, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public void sendTakePhotoIntent() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }

            if (photoFile != null) {
                p_Uri = FileProvider.getUriForFile(requireActivity().getApplicationContext(),
                        getContext().getPackageName(), photoFile);

                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, p_Uri);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }
    public void sendTakeQRIntent(){
        Intent takeQRintent = new Intent(getActivity(), ScanQR.class);
        startActivityForResult(takeQRintent, REQUEST_IMAGE_CAPTURE);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
//            ((ImageView) getView().findViewById(R.id.imageView)).setImageURI(p_Uri);
            ExifInterface exif = null;

            Bitmap bitmap = BitmapFactory.decodeFile(imageFilePath);
            try {
                exif = new ExifInterface(imageFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            int exifOrientation;
            int exifDegree;

            if (exif != null) {
                exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                exifDegree = exifOrientationToDegrees(exifOrientation);
            } else {
                exifDegree = 0;
            }
//            ((ImageView)getView().findViewById(R.id.imageView)).setImageBitmap(rotate(bitmap, exifDegree));
//                        ((ImageView)getView().findViewById(R.id.imageView)).setImageBitmap(bitmap);
            // Use a model that's applicable for your use case (see "Implement basic use cases" below)
            // For text-and-images input (multimodal), use the gemini-pro-vision model
            SafetySetting harassmentSafety = new SafetySetting(HarmCategory.HARASSMENT, BlockThreshold.NONE);
            SafetySetting hateSpeechSafety  = new SafetySetting(HarmCategory.HATE_SPEECH, BlockThreshold.NONE);
            SafetySetting dangerousContentSafety  = new SafetySetting(HarmCategory.DANGEROUS_CONTENT, BlockThreshold.NONE);
            SafetySetting sexuallyExplicitSafety  = new SafetySetting(HarmCategory.SEXUALLY_EXPLICIT, BlockThreshold.NONE);

            GenerativeModel gm = new GenerativeModel("gemini-pro-vision",
                    "AIzaSyB396H5muKxjc9OK5744vD6Mkr08xPCFw8",
                    // Access your API key as a Build Configuration variable (see "Set up your API key" above)
                    null,
                    Arrays.asList(harassmentSafety, hateSpeechSafety, dangerousContentSafety, sexuallyExplicitSafety)
            );


            // Use the GenerativeModelFutures Java compatibility layer which offers
            // support for ListenableFuture and Publisher APIs
            GenerativeModelFutures model = GenerativeModelFutures.from(gm);

            Content content = new Content.Builder()
                    .addText("사진 속 명함에 들어있는 정보들을 key/value 형식으로 알려줘. 예를 들면, 이름/김철수 와 같이 알려줘.")
                    .addImage(bitmap)
                    .build();

            ListenableFuture<GenerateContentResponse> response = model.generateContent(content);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
                    @Override
                    public void onSuccess(GenerateContentResponse result) {
                        String resultText = result.getText();
                        //                System.out.println(resultText);
                        Toast.makeText(getActivity(), resultText, Toast.LENGTH_SHORT).show();

                        LinearLayout containerLayout = getView().findViewById(R.id.container_layout);
                        containerLayout.setOrientation(LinearLayout.VERTICAL);

                        Map<String, Object> data = new HashMap<>();
                        String[] lines = resultText.split("\n");
                        String delimiter = "/";
                        for (String line : lines) {
                            //Toast.makeText(getActivity(), "line is " + line, Toast.LENGTH_SHORT).show();
                            if (line.contains(delimiter)) {
                                int delimiterIndex = line.indexOf(delimiter);
                                String key = line.substring(0, delimiterIndex).trim();
                                String val = line.substring(delimiterIndex + delimiter.length()).trim();
                                //data.put(key, val);
                                //Toast.makeText(getActivity(), key+"key", Toast.LENGTH_SHORT).show();
                                //Toast.makeText(getActivity(), val+"val", Toast.LENGTH_SHORT).show();


//            EditText editText = new EditText(getActivity().getApplicationContext());
//            editText.setLayoutParams(new ViewGroup.LayoutParams(
//                    ViewGroup.LayoutParams.MATCH_PARENT,
//                    ViewGroup.LayoutParams.WRAP_CONTENT));
//            containerLayout.addView(editText);
                                LinearLayout newRow = new LinearLayout(requireContext());

                                LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(
                                        0,
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        3); // 가로 크기의 비율을 3으로 지정
                                layoutParams1.setMargins(8, 8, 8, 0); // 마진 추가
                                EditText editText1 = new AppCompatEditText(requireContext());
                                editText1.setLayoutParams(layoutParams1);
                                editText1.setText(key);
                                newRow.addView(editText1);
                                keyEditText.add(editText1);

                                // 두 번째 EditText
                                EditText editText2 = new AppCompatEditText(requireContext());
                                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(
                                        0,
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        7); // 가로 크기의 비율을 7로 지정
                                layoutParams2.setMargins(8, 0, 8, 8); // 마진 추가

                                editText2.setLayoutParams(layoutParams2);
                                editText2.setText(val);
                                newRow.addView(editText2);

                                valEditText.add(editText2);
//            editTextList.add(editText);
                                newRow.setOrientation(LinearLayout.HORIZONTAL);
                                containerLayout.addView(newRow);


                                //Toast.makeText(getActivity(), "size: "+editTextList.size(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        // 모든 EditText가 만들어졌으면 [추가하기] 버튼 생성
                        Button button = new AppCompatButton(requireContext());
                        button.setText("명함 추가하기"); // 버튼 텍스트 설정

                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT);
                        layoutParams.setMargins(8, 8, 8, 8); // 마진 추가
                        button.setLayoutParams(layoutParams);

                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // 버튼 클릭 시 Firestore에 새 문서 추가
                                addNewDocumentToFirestore(bitmap);
                            }
                        });

                        containerLayout.addView(button);


//                        data.put("name", "John Doe");
//                        data.put("age", 30);
//                        data.put("email", "johndoe@example.com");

//                        // Firestore에 데이터 추가
//                        db.collection("users")
//                                .add(data)
//                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                                    @Override
//                                    public void onSuccess(DocumentReference documentReference) {
//                                        Log.d("TAG", "DocumentSnapshot added with ID: " + documentReference.getId());
//                                    }
//                                })
//                                .addOnFailureListener(new OnFailureListener() {
//                                    @Override
//                                    public void onFailure(@NonNull Exception e) {
//                                        Log.w("TAG", "Error adding document", e);
//                                    }
//                                });


                        ((TextView) getView().findViewById(R.id.cameraFragmentText)).setText(resultText);
                        ((TextView) getView().findViewById(R.id.cameraFragmentText)).setTextSize(2, 16F);
                        ((TextView) getView().findViewById(R.id.cameraFragmentText)).setVisibility(View.INVISIBLE);
//                        ((ImageView)getView().findViewById(R.id.imageView)).setImageBitmap(bitmap);
                        ((ImageView)getView().findViewById(R.id.imageView)).setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        //t.printStackTrace();
                        StringWriter errors = new StringWriter();
                        t.printStackTrace(new PrintWriter(errors));
                        String errorStr = errors.toString();
                        Log.d("GENAI", errorStr);
                        Toast.makeText(getActivity(), "명함정보 분석에 실패하여 메인화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
                        Toast.makeText(getActivity(), errorStr, Toast.LENGTH_LONG).show();
                        ((HomePage)getActivity()).transferTo(new HomeFragment());
                    }
                }, this.getContext().getMainExecutor());
            }
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "TEST_" + timeStamp + "_";
        File storageDir = getContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,      /* prefix */
                ".jpg",         /* suffix */
                storageDir          /* directory */
        );
        imageFilePath = image.getAbsolutePath();
        return image;
    }


    private void addToReferenceArray(DocumentReference newDocRef) {
        // 특정 문서의 참조 가져오기
        DocumentReference specificDocRef = db.collection("sampleCollection").document(Uid);

        // 특정 문서 가져오기
        specificDocRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // 특정 문서가 존재하는 경우
                        // 기존의 배열 필드 가져오기
                        List<DocumentReference> referenceArray = (List<DocumentReference>) document.get("namecards");

                        // 새로 추가된 문서의 참조를 배열에 추가
                        referenceArray.add(newDocRef);

                        // 업데이트된 배열을 문서에 다시 저장
                        specificDocRef.update("namecards", referenceArray)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(getActivity().getApplicationContext(), "내 Storage에 명함을 추가했습니다.", Toast.LENGTH_SHORT).show();
//                                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.main_content, new HomeFragment()).commit();
                                            ((HomePage)getActivity()).transferTo(new HomeFragment());
                                        } else {
                                            // 실패 시 처리할 작업
                                            Toast.makeText(getActivity().getApplicationContext(), "내 Storage에 명함 추가에 실패했습니다.", Toast.LENGTH_SHORT).show();
                                            ((HomePage)getActivity()).transferTo(new HomeFragment());
                                        }
                                    }
                                });
                    } else {
                        Toast.makeText(getActivity().getApplicationContext(), "내 Storage가 없습니다.", Toast.LENGTH_SHORT).show();

                    }
                } else {
                    Toast.makeText(getActivity().getApplicationContext(), "내 Storage를 가져오는 데 실패했습니다. 인터넷 연결을 확인하세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    // Firestore에 새 문서를 추가하는 메서드
    private void addNewDocumentToFirestore(Bitmap bitmap) {
        final String[] downloadUrl = {""};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] data = baos.toByteArray();
        // byte array to firebase storage
        storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();
        StorageReference imagesRef = storageRef.child("images/" + System.currentTimeMillis() + ".jpg");
        UploadTask uploadTask = imagesRef.putBytes(data);
        uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // 업로드 성공 시 다운로드 URL 가져오기
                imagesRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        downloadUrl[0] = uri.toString();
                        Toast.makeText(getActivity().getApplicationContext(), "Image upload OK: " + downloadUrl[0], Toast.LENGTH_SHORT).show();
                        // 새로운 데이터 맵 생성
                        Map<String, Object> newData = new HashMap<>();

                        for (int i = 0; i < keyEditText.size(); i++) {
                            String key = keyEditText.get(i).getText().toString();
                            if (key.equals("모바일") || key.equals("핸드폰") || key.equals("휴대전화") || key.equals("휴대전화번호")) {
                                key = "phoneNum";
                            } else if ( key.equals("전화번호") || key.equals("연락처") ) {
                                key = "phoneNum";
                            } else if (key.equals("이름") || key.equals("성함") || key.equals("성명")) {
                                key = "name";
                            } else if (key.equals("이메일") || key.equals("전자우편") || key.equals("메일주소")) {
                                key = "email";
                            }
                            String val = valEditText.get(i).getText().toString();
                            newData.put(key, val);
                        }

                        if (downloadUrl[0].length() > 1) {
                            Toast.makeText(getActivity().getApplicationContext(), "downloadUrl[0].length()" + Integer.toString(downloadUrl[0].length()), Toast.LENGTH_SHORT).show();
                            ArrayList<String> mynamecards = new ArrayList<String>(1);
                            mynamecards.add(downloadUrl[0]);
                            newData.put("mynamecards", mynamecards);
                        }

                        Toast.makeText(getActivity().getApplicationContext(), "downloadUrl[0]" + downloadUrl[0], Toast.LENGTH_SHORT).show();

                        // Firestore에 데이터 추가
                        db.collection("sampleCollection")
                                .add(newData)
                                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentReference> task) {
                                        if (task.isSuccessful()) {
                                            // 새로 추가된 문서의 DocumentReference 가져오기
                                            DocumentReference newDocRef = task.getResult();
                                            Toast.makeText(getActivity().getApplicationContext(), "Firebase에 새 명함이 추가되었습니다. " + newDocRef.toString(), Toast.LENGTH_SHORT).show();
                                            // 특정 문서의 배열 필드에 새로 추가된 문서의 참조를 추가
                                            addToReferenceArray(newDocRef);
                                        } else {
                                            Toast.makeText(getActivity().getApplicationContext(), "Firebase 새 명함 추가에 실패했습니다.", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // 업로드 실패 처리
                Toast.makeText(getActivity().getApplicationContext(), "Image upload failed: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

}