package androidtown.org.termproject;

import static androidx.compose.ui.semantics.SemanticsPropertiesKt.dismiss;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class InitPopUpActivity extends Activity {

    private EditText et_text_name;
    private EditText et_text_phoneNum;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.init_popup_activity);

        // 다이얼로그의 배경을 투명으로 만든다.
        Objects.requireNonNull(getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        // 커스텀 다이얼로그의 각 위젯들을 정의한다.
        et_text_name = findViewById(R.id.edit_text_name);
        Button saveButton = findViewById(R.id.btnSave);
        et_text_phoneNum =findViewById(R.id.edit_text_phoneNum);


        // 버튼 리스너 설정
        saveButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                // '확인' 버튼 클릭시
                // ...코드..
//                Toast.makeText(getApplicationContext(),et_text_name.getText().toString() + "\n" + et_text_phoneNum.getText().toString(), Toast.LENGTH_SHORT).show();
                // Custom Dialog 종료
                Map<String, Object> newData = new HashMap<>();
                newData.put("name", et_text_name.getText().toString());
                newData.put("phoneNum", et_text_phoneNum.getText().toString());
                FirebaseFirestore db = FirebaseFirestore.getInstance();
//                Toast.makeText(getApplicationContext(), "db : "+db, Toast.LENGTH_SHORT).show();
                // 특정 문서의

                String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
//                Toast.makeText(getApplicationContext(), "Uid : "+Uid, Toast.LENGTH_SHORT).show();
                // 특정 문서의

                // Firestore에 데이터 추가
                db.collection("sampleCollection").document(Uid)
                        .set(newData)
                        .addOnCompleteListener(
                                new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
//                                        Toast.makeText(getApplicationContext(), "firebase OK!", Toast.LENGTH_SHORT).show();
                                        // 특정 문서의
                                    }
                                }
                        );
                finish();
            }
        });
    }
    public void mOnClose(View v){
        finish();
    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        // 바깥 레이어 클릭시 안닫히게
        if(event.getAction() ==MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }
    @Override
    public void onBackPressed(){
        //안드로이드 백버튼 막기
        return;
    }
}

