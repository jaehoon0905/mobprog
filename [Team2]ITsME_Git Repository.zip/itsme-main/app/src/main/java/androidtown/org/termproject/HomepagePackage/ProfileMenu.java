package androidtown.org.termproject.HomepagePackage;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;


import androidtown.org.termproject.InitialPart.JoinActivity;
import androidtown.org.termproject.R;

public class ProfileMenu extends Fragment {


    private GoogleSignInClient mGoogleSignInClient;
    Button logOut;
    ImageButton backArrow;

   private FirebaseAuth mAuth;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStat) {
        return inflater.inflate(R.layout.profile_menu_fragment, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        Fragment ProfileFragment = new ProfileFragment();
        logOut = (Button) getActivity().findViewById(R.id.Logout);
        backArrow = (ImageButton) getActivity().findViewById(R.id.backArrow);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((HomePage)getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.main_content, ProfileFragment).addToBackStack(null).commit();
            }
        });

        // 구글 로그아웃
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(getContext(),"눌림",Toast.LENGTH_SHORT).show();
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(getString(R.string.default_web_client_id))
                        .requestEmail()
                        .build();

                mGoogleSignInClient = GoogleSignIn.getClient(getActivity(), gso);
                //mAuth.signOut();
                mGoogleSignInClient.signOut();
                Intent intent = new Intent(getActivity(), JoinActivity.class);
                startActivity(intent);

            }
        });
    }
}
