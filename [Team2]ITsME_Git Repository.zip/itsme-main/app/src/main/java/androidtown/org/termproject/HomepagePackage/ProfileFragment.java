package androidtown.org.termproject.HomepagePackage;

import static android.app.Activity.RESULT_OK;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidtown.org.termproject.PopUpActivity;
import androidtown.org.termproject.PopUpActivity_profileMenu;
import androidtown.org.termproject.R;
import androidtown.org.termproject.data.User;

public class ProfileFragment extends Fragment {
    private static final int REQUEST_CODE = 1;
    ImageButton menubar;
    Fragment ProfileMenu = new ProfileMenu();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.profile_fragment, container, false);
//        mProfilePhoto = (ImageView) view.findViewById(R.id.)
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        menubar = (ImageButton) getActivity().findViewById(R.id.menubar);
        menubar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((HomePage) getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.main_content, ProfileMenu).commit();
            }
        });

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        ImageView my_namecard = getActivity().findViewById(R.id.my_namecard);
        DocumentReference docRef = db.collection("sampleCollection").document(Uid);

        // Firestore에서 문서 가져오기
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // 문서가 존재하면 배열을 가져옵니다.
                        List<String> imageUrlList = (List<String>) document.get("mynamecards");

                        if (imageUrlList != null && imageUrlList.size() > 0) {
                            String element_url = imageUrlList.get(0); // Get most recent namecard image url
                            if (element_url.startsWith("gs://")) {
                                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                                StorageReference imgRef = firebaseStorage.getReferenceFromUrl(element_url);
                                if (imgRef != null) {
                                    imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            Glide.with(getActivity())
                                                    .load(uri)
                                                    .centerCrop()
                                                    .into(my_namecard);
                                        }
                                    });
                                }
                            } else {
                                Glide.with(getActivity())
                                        .load(element_url)
                                        .centerCrop()
                                        .into(my_namecard);
                            }
                        }
                    }

                } else {
                    Log.d("Firestore", "No such document");
                    Toast.makeText(getActivity().getApplicationContext(), "No such document", Toast.LENGTH_SHORT).show();
                }
            }
        });
        drawHistory(db, Uid);


    }

    /**
     * drawHistory : Get Recent business card images from firebase storage and draw them
     * @param db Firebase Firestore Instance
     * @param Uid current user Id
     */
    public void drawHistory(FirebaseFirestore db, String Uid) {

        // TableRow를 가져옵니다.
        TableLayout tableLayout = getActivity().findViewById(R.id.previousNamecardLayout);


        // TableRow 안에 있는 모든 ImageView를 ArrayList에 추가합니다.
        ArrayList<ImageView> imageViewList = new ArrayList<>();
        for (int i = 0; i < tableLayout.getChildCount(); i++) {
            if (tableLayout.getChildAt(i) instanceof TableRow) {
                TableRow tableRow = (TableRow) tableLayout.getChildAt(i);
                for(int j = 0; j < tableRow.getChildCount(); j++) {
                    if (tableRow.getChildAt(j) instanceof ImageView) {
                        imageViewList.add((ImageView) tableRow.getChildAt(j));
                    }
                }
            }
        }
        // 컬렉션과 문서 참조
        DocumentReference docRef = db.collection("sampleCollection").document(Uid);

        // Firestore에서 문서 가져오기
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // 문서가 존재하면 배열을 가져옵니다.
                        List<String> imageUrlList = (List<String>) document.get("mynamecards");

                        // 배열이 null이 아닌지 확인합니다.
                        if (imageUrlList == null) {
                            imageUrlList = new ArrayList<>();
                        }

//                        ArrayList<String> imageUrlList = new ArrayList<>();
                        int namecardSize = imageUrlList.size();
                        if ( namecardSize > 8 ) {
                            namecardSize = 8;
                        }
                        for (int i = 0; i < namecardSize; i++) {
                            String url = imageUrlList.get(i);
//                            Toast.makeText(getActivity().getApplicationContext(), "url " + url, Toast.LENGTH_SHORT).show();
                            if (url.startsWith("gs://")){
                                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                                StorageReference imgRef = firebaseStorage.getReferenceFromUrl(url);
                                if (imgRef != null) {
                                    int finalI = i;
                                    imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            Glide.with(getActivity())
                                                    .load(uri)
                                                    .centerCrop()
                                                    .into(imageViewList.get(finalI));

                                            imageViewList.get(finalI).setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    Intent intent =new Intent(getActivity(), PopUpActivity_profileMenu.class);
                                                    intent.putExtra("imageArrayIndex", finalI);
                                                    startActivityForResult(intent, REQUEST_CODE);
                                                }
                                            });
                                        }
                                    });
                                }
                            }
                            else {
                                Glide.with(getActivity())
                                        .load(imageUrlList.get(i))
                                        .centerCrop()
                                        .into(imageViewList.get(i));
                                int finalI1 = i;
                                imageViewList.get(i).setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(getActivity(), PopUpActivity_profileMenu.class);
                                        intent.putExtra("imageArrayIndex", finalI1);
                                        startActivityForResult(intent, REQUEST_CODE);
                                    }
                                });
                            }
                        }

                    } else {
                        Log.d("Firestore", "No such document");
//                        Toast.makeText(getActivity().getApplicationContext(), "No such document", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.d("Firestore", "get failed with ", task.getException());
//                    Toast.makeText(getActivity().getApplicationContext(), "get failed with : " + task.getException().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
//        Toast.makeText(getActivity().getApplicationContext(), "drawHistory Done? 1 ", Toast.LENGTH_SHORT).show();
    }
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
//            Toast.makeText(getActivity().getApplicationContext(), "requestCode " + Integer.toString(requestCode) + " and resultCode" + Integer.toString(resultCode), Toast.LENGTH_SHORT).show();
//            Toast.makeText(getActivity().getApplicationContext(), "requestCode " + Integer.toString(requestCode) + " and resultCode" + Integer.toString(resultCode), Toast.LENGTH_SHORT).show();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            drawHistory(db, Uid);

            ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().detach(this).commit();

            new Handler().postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    //딜레이 후 시작할 코드 작성
                    ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().attach(ProfileFragment.this).commit();
                }
            }, 1000);// 1초 정도 딜레이를 준 후 시작


//            Toast.makeText(getActivity().getApplicationContext(), "drawHistory Done? 2 ", Toast.LENGTH_SHORT).show();
        }


    }

//                    imageView.getLayoutParams().height = "300px";


}