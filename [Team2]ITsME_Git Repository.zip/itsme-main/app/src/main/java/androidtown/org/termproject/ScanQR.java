package androidtown.org.termproject;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


import java.io.IOException;
import java.util.List;

import androidtown.org.termproject.HomepagePackage.HomeFragment;
import androidtown.org.termproject.HomepagePackage.HomePage;

public class ScanQR extends AppCompatActivity {
    SurfaceView surfaceView;
    TextView textViewBarCodeValue;
    private BarcodeDetector barcodeDetector;
    private CameraSource cameraSource;
    private static final int REQUEST_CAMERA_PERMISSION = 201;
    String intentData = "";
    String Uid;

    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_q_r);
        initComponents();
        Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    }

    private void initComponents() {
        textViewBarCodeValue = findViewById(R.id.txtBarcodeValue);
        surfaceView = findViewById(R.id.surfaceView);
    }

    private void initialiseDetectorsAndSources() {
//        Toast.makeText(getApplicationContext(), "Barcode scanner started", Toast.LENGTH_SHORT).show();
        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.ALL_FORMATS)
                .build();

        cameraSource = new CameraSource.Builder(this, barcodeDetector)
                .setRequestedPreviewSize(1920, 1080)
                .setAutoFocusEnabled(true) //you should add this feature
                .build();

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                openCamera();
            }
            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }
            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
//                Toast.makeText(getApplicationContext(), "To prevent memory leaks barcode scanner has been stopped", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barCode = detections.getDetectedItems();
                if (barCode.size() > 0) {
                    setBarCode(barCode);
                }
            }
        });
    }

    private void openCamera(){
        try {
            if (ActivityCompat.checkSelfPermission(ScanQR.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                cameraSource.start(surfaceView.getHolder());
            } else {
                ActivityCompat.requestPermissions(ScanQR.this, new
                        String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setBarCode(final SparseArray<Barcode> barCode){
        textViewBarCodeValue.post(new Runnable() {
            @Override
            public void run() {
                intentData = barCode.valueAt(0).displayValue;
                textViewBarCodeValue.setText(intentData);
                copyToClipBoard(intentData);
                //
                db = FirebaseFirestore.getInstance();
                DocumentReference specificDocRef = db.collection("sampleCollection").document(Uid);

                // 특정 문서 가져오기
                specificDocRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // 특정 문서가 존재하는 경우
                                // 기존의 배열 필드 가져오기


                                // 참조할 문서의 CollectionReference 가져오기
                                DocumentReference scanedDocRef = db.collection("sampleCollection").document(intentData);

                                // 추가할 참조 생성
                                // DocumentReference referenceToAdd = db.collection("sampleCollection").document("reference_document_id");

                                List<DocumentReference> referenceArray = (List<DocumentReference>) document.get("namecards");

                                // 새로 추가된 문서의 참조를 배열에 추가

                                if (!referenceArray.contains(scanedDocRef)) {
                                    referenceArray.add(scanedDocRef);

                                    // 업데이트된 배열을 문서에 다시 저장
                                    specificDocRef.update("namecards", referenceArray)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        Toast.makeText(getApplicationContext(), "내 Storage에 명함을 추가했습니다.", Toast.LENGTH_SHORT).show();
//                                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.main_content, new HomeFragment()).commit();
//                                                    ((HomePage)getActivity()).transferTo(new HomeFragment());
                                                        finish();
                                                    } else {
                                                        // 실패 시 처리할 작업
                                                        Toast.makeText(getApplicationContext(), "내 Storage에 명함 추가에 실패했습니다.", Toast.LENGTH_SHORT).show();
//                                                    ((HomePage)getActivity()).transferTo(new HomeFragment());
                                                        finish();
                                                    }
                                                }
                                            });
                                } else {
//                                    Toast.makeText(getApplicationContext(), "이미 등록된 명함입니다.", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            } else {
//                                Toast.makeText(getApplicationContext(), "내 Storage가 없습니다.", Toast.LENGTH_SHORT).show();

                            }
                        } else {
//                            Toast.makeText(getApplicationContext(), "내 Storage를 가져오는 데 실패했습니다. 인터넷 연결을 확인하세요.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        cameraSource.release();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initialiseDetectorsAndSources();
    }

    private void copyToClipBoard(String text){
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("QR code Scanner", text);
        clipboard.setPrimaryClip(clip);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CAMERA_PERMISSION && grantResults.length>0){
            if (grantResults[0] == PackageManager.PERMISSION_DENIED)
                finish();
            else
                openCamera();
        }else
            finish();
    }
}
