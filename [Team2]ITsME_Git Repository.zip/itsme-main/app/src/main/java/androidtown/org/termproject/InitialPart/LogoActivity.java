package androidtown.org.termproject.InitialPart;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import javax.annotation.Nullable;


import androidtown.org.termproject.HomepagePackage.HomePage;
import androidtown.org.termproject.InitialPart.*;
import androidtown.org.termproject.R;


public class LogoActivity extends Activity implements GoogleApiClient.OnConnectionFailedListener {
    private static final int RC_SIGN_IN = 10;
    private GoogleSignInClient mGoogleSignInClient;
    public FirebaseAuth mAuth;
    // 구글 로그인 part


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logo_page);

        // 파이어베이스에서 유저 객체 가져오기
        mAuth = FirebaseAuth.getInstance();

        // 구글 계정 가져오기
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(LogoActivity.this);

        Handler hand = new Handler();
        hand.postDelayed(new Runnable() {

            @Override
            public void run() {
                // 구글 로그인 되어있다면 firebaseAuthWithGoogle 로 계정 호출.
                if (account != null) {
                    // Firebase에 인증
                    firebaseAuthWithGoogle(account);
                }
                // 구글 로그인이 안되어 있다면
                else{
                    // JoinActivity로 보내서 구글 가입 하기 or 로그인 직접 하기
                    Intent intent = new Intent(LogoActivity.this, JoinActivity.class);
                    startActivity(intent);
                }
            }
        }, 1000);

    }

    private void firebaseAuthWithGoogle(@Nullable GoogleSignInAccount acct) {
        if (acct != null) {
            AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
            mAuth.signInWithCredential(credential)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //  if (!task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
//                            Toast.makeText(getApplicationContext(), "ㅎㅇ222",
//                                    Toast.LENGTH_SHORT).show();
                            toHomepageActivity(user);
//                            } else {
//                                // If sign in fails, display a message to the user.
//                                Log.w(TAG, "signInWithCredential:failure", task.getException());
//
//                                Toast.makeText(JoinActivity.this, "Authentication failed.",
//                                        Toast.LENGTH_SHORT).show();
//                            }
                        }
                    });
        } else {
            Log.w(TAG, "Google sign in account is null");
            // Handle null account
        }
    }


    private void toHomepageActivity(FirebaseUser user){
//        Toast.makeText(getApplicationContext(),"성공 @ logo",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, HomePage.class));
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

}
