package androidtown.org.termproject.HomepagePackage.Card;
// BusinessCard.java

import java.util.ArrayList;
import java.util.List;

public class BusinessCard {
    private List<TextElement> textElements;

    public BusinessCard() {
        textElements = new ArrayList<>();
    }

    public List<TextElement> getTextElements() {
        return textElements;
    }

    public void setTextElements(List<TextElement> textElements) {
        this.textElements = textElements;
    }

    public void addTextElement(TextElement element) {
        textElements.add(element);
    }
}

// TextElement.java

