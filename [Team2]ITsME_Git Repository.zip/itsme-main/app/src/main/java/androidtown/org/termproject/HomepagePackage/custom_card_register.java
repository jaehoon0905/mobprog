package androidtown.org.termproject.HomepagePackage;

import android.app.MediaRouteButton;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;
import com.skydoves.colorpickerview.sliders.AlphaSlideBar;
import com.skydoves.colorpickerview.sliders.BrightnessSlideBar;

import androidtown.org.termproject.R;

public class custom_card_register extends AppCompatActivity {

    EditText name;

    EditText p_num;

    EditText department;

    EditText et;

    TextView colorTextView;
    View colorView;

    int cnt = 0;

    // 양손 제스처로 edit text 사이즈를 키우거나 줄임.
    private ScaleGestureDetector scaleGestureDetector;
    private float scaleFactor = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.custom_card_register);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.test_123), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // findViewById 부분
        colorView = findViewById(R.id.color_view);

        colorTextView = findViewById(R.id.color_text_view);

        Button btn = findViewById(R.id.btn2);

        Button back_btn = findViewById(R.id.back_btn);

        LinearLayout ll = findViewById(R.id.test_123);

        Button edit_btn = findViewById(R.id.edit_btn);


        ColorPickerView colorPickerView = findViewById(R.id.colorPickerView);

        BrightnessSlideBar brigSliderBar = findViewById(R.id.bring_slider);
        colorPickerView.attachBrightnessSlider(brigSliderBar);

        //투명도 조절 슬라이더
        AlphaSlideBar alphaSlideBar = findViewById(R.id.alph_sliderBar);
        colorPickerView.attachAlphaSlider(alphaSlideBar);


        int code;

        // 배경색 지정 버튼 클릭시 배경색 지정 위젯 보이기
        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color_visible(v);
            }
        });

        // 화면 터치시 모든위젯 안보이기
        ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        colorPickerView.setColorListener(new ColorEnvelopeListener() {
            @Override
            public void onColorSelected(ColorEnvelope envelope, boolean fromUser) {

                //색상 코드 가져오기
                colorTextView.setText(envelope.getHexCode());

                //색상가져오기
                colorView.setBackgroundColor(envelope.getColor());

                //색상코드로 배경 색상 변경
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ll.setBackgroundColor(envelope.getColor());
                    }
                });
            }
        });

        edit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 배경색 지정 위젯 안보이기
                color_invisible(v);

                et = new EditText(getApplicationContext());
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                et.setX(40);
                et.setY(40);
                et.setId(View.generateViewId());

                et.setLayoutParams(p);

                et.setText("editText");
                //et.setId(cnt);

                ll.addView(et);

                scaleGestureDetector = new ScaleGestureDetector(getApplicationContext(), new ScaleListener(et));

                et.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {

                        if (event.getAction() == MotionEvent.ACTION_MOVE) {
                            //et.setRotation(20);
                            float offsetX = event.getX() - ((float) v.getWidth() / 2);
                            float offsetY = event.getY() - ((float) v.getHeight() / 2);
                            v.setX(v.getX() + offsetX);
                            v.setY(v.getY() + offsetY);
                        }
                        return true;
                    }
                });
            }
        });



    }   // Oncreate

    // 배경색 지정 위젯 화면 출력 or 출력 안함 method
    private void color_invisible(View v) {
        findViewById(R.id.colorPickerView).setVisibility(v.INVISIBLE);
        findViewById(R.id.color_text_view).setVisibility(v.INVISIBLE);
        findViewById(R.id.btn2).setVisibility(v.INVISIBLE);
        findViewById(R.id.alph_sliderBar).setVisibility(v.INVISIBLE);
        findViewById(R.id.bring_slider).setVisibility(v.INVISIBLE);
    }
    private void color_visible(View v) {
        findViewById(R.id.colorPickerView).setVisibility(v.VISIBLE);
        findViewById(R.id.color_text_view).setVisibility(v.VISIBLE);
        findViewById(R.id.btn2).setVisibility(v.VISIBLE);
        findViewById(R.id.alph_sliderBar).setVisibility(v.VISIBLE);
        findViewById(R.id.bring_slider).setVisibility(v.VISIBLE);
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }


    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private EditText view;

        public ScaleListener(EditText view) {
            this.view = view;
        }

        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scaleFactor *= detector.getScaleFactor();

            // 최소/최대 크기 제한
            scaleFactor = Math.max(0.1f, Math.min(scaleFactor, 5.0f));

            // 버튼의 크기 조절
            view.setScaleX(scaleFactor);
            view.setScaleY(scaleFactor);

            return true;
        }
    }
}
