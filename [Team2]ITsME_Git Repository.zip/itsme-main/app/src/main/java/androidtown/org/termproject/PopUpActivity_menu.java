package androidtown.org.termproject;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.vision.L;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class PopUpActivity_menu extends Activity {
    Button delete;
    String targetDocId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup_activity_menu);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        if (intent != null) {
            targetDocId = intent.getStringExtra("elemDocRef");
        }

        String Uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        delete = findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DocumentReference docRef = db.collection("sampleCollection").document(Uid);
                if (targetDocId != null) {
                    DocumentReference elementToRemove = db.collection("sampleCollection").document(targetDocId);
                    // Remove the element from the array
                    docRef.update("namecards", FieldValue.arrayRemove(elementToRemove))
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        // Element successfully removed
                                        System.out.println("Element removed successfully");
                                    } else {
                                        // Handle the error
                                        System.err.println("Error removing element: " + task.getException());
                                    }
                                }
                            });
                }

                Intent intent = new Intent();
                intent.putExtra("delete", true);
                setResult(RESULT_OK, intent);
                finish();

            }
        });
    }

    public void mOnClose(View v) {
        finish();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 바깥 레이어 클릭시 안닫히게
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        //안드로이드 백버튼 막기
        return;
    }
}